# PacMan
 PacMan Game

Notes:
    -   Added monsters
    -   Added option for definition of player name
    -   Best result saved with player name in local storagr(In cases when bowsers not support loscal storage it will be saved per session in variable)
    -   Added randomal borders
    -   When a monster crosses with a pacman, 5 points are deducted from the current score